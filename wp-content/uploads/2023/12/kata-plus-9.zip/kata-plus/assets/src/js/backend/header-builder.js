/**
 * Header Builder.
 *
 * @author  ClimaxThemes
 * @package	Kata Plus
 * @since	1.0.0
 */
'use strict';

jQuery(document).ready(function () {
	// Add New Row
	jQuery(jQuery('#elementor-preview-iframe')).on('load', function () {
		var $elementorPreviewIframe = jQuery(
			'#elementor-preview-iframe'
		).contents();
		$elementorPreviewIframe
			.find('.elementor-add-section-drag-title')
			.html('Add new row');
		$elementorPreviewIframe
			.find('.elementor-add-section-button')
			.attr('title', 'Add New 3 Column Section');
		$elementorPreviewIframe
			.find('body')
			.on('click', '.elementor-add-section-button', function () {
				jQuery(this)
					.parents('.elementor-add-section')
					.find(
						'ul.elementor-select-preset-list li.elementor-column[data-structure="30"]'
					)
					.trigger('click');
				return false;
			});
		$elementorPreviewIframe
			.find('body')
			.on('click', '.elementor-editor-element-add', function () {
				jQuery(this)
					.parents('.elementor-section')
					.siblings('.elementor-add-section')
					.find(
						'ul.elementor-select-preset-list li.elementor-column[data-structure="30"]'
					)
					.trigger('click');
				return false;
			});
	});
});
