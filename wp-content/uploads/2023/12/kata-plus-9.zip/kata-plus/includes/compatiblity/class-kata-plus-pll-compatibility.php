<?php

/**
 * Polylang Compatibility Class.
 *
 * @author  ClimaxThemes
 * @package Kata Plus
 * @since   1.2.0
 */

// Don't load directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;

if ( ! class_exists( 'Kata_Plus_Pll_Compatibility' ) ) {

	class Kata_Plus_Pll_Compatibility extends Kata_Plus_Compatibility {

		/**
		 * Instance of this class.
		 *
		 * @since   1.2.0
		 * @access  public
		 * @var     Kata_Plus_Pll_Compatibility
		 */
		public static $instance;

		/**
		 * Provides access to a single instance of a module using the singleton pattern.
		 *
		 * @since   1.2.0
		 * @return  object
		 */
		public static function get_instance() {

			if ( self::$instance === null ) {

				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Constructor.
		 *
		 * @since   1.2.0
		 */
		public function __construct() {

			$this->definitions();
			$this->actions();
		}

		/**
		 * Add actions.
		 *
		 * @since   1.2.0
		 */
		public function actions() {

			// add_action( 'init', [$this, 'set_default_language_for_builders'], 999 );
			// add_action( 'init', [$this, 'set_builders_language'], 999 );
			add_filter( 'pll_get_post_types', array( $this, 'add_cpt_to_pll' ), 10, 2 );
			add_filter( 'pll_get_taxonomies', array( $this, 'add_tax_to_pll' ), 10, 2 );
			add_action( 'elementor/element/wp-post/document_settings/before_section_start', array( $this, 'multi_language' ), 10, 2 );
			add_action( 'elementor/element/wp-page/document_settings/before_section_start', array( $this, 'multi_language' ), 10, 2 );
		}

		/**
		 * Return registred languages.
		 *
		 * @since   1.2.0
		 */
		public function registred_languages() {
			pll_languages_list();
		}

		/**
		 * Add Kata Post types to polylang.
		 *
		 * @since   1.2.0
		 */
		public function add_cpt_to_pll( $post_types, $is_settings ) {

			if ( $is_settings ) {

				unset( $post_types['kata_plus_builder'] );
				unset( $post_types['kata_mega_menu'] );
				unset( $post_types['elementor_library'] );
				unset( $post_types['kata_grid'] );
				unset( $post_types['kata_recipe'] );
				unset( $post_types['kata_team_member'] );
				unset( $post_types['kata_testimonial'] );
			} else {

				$post_types['kata_plus_builder'] = 'kata_plus_builder';
				$post_types['kata_mega_menu']    = 'kata_mega_menu';
				$post_types['elementor_library'] = 'elementor_library';
				$post_types['kata_grid']         = 'kata_grid';
				$post_types['kata_recipe']       = 'kata_recipe';
				$post_types['kata_team_member']  = 'kata_team_member';
				$post_types['kata_testimonial']  = 'kata_testimonial';
			}
			return $post_types;
		}

		/**
		 * Add Kata taxonomies to polylang.
		 *
		 * @since   1.2.0
		 */
		public function add_tax_to_pll( $taxonomies, $is_settings ) {

			if ( $is_settings ) {

				unset( $taxonomies['grid_category'] );
				unset( $taxonomies['grid_tags'] );
				unset( $taxonomies['kata_recipe_category'] );
				unset( $taxonomies['kata_recipe_tag'] );
			} else {

				$taxonomies['grid_category']        = 'grid_category';
				$taxonomies['grid_tags']            = 'grid_tags';
				$taxonomies['kata_recipe_category'] = 'kata_recipe_category';
				$taxonomies['kata_recipe_tag']      = 'kata_recipe_tag';
			}

			return $taxonomies;
		}

		/**
		 * Add get language.
		 *
		 * @since   1.2.0
		 */
		public function get_currnet_language() {

			if ( ! function_exists( 'pll_current_language' ) ) {
				require_once WP_PLUGIN_DIR . '/polylang/include/api.php';
			}

			if ( function_exists( 'pll_default_language' ) && ! pll_current_language() ) {
				return pll_default_language();
			} elseif ( function_exists( 'pll_current_language' ) && pll_current_language() ) {
				return pll_current_language();
			}
		}

		/**
		 * Add get language.
		 *
		 * @since   1.2.0
		 */
		public function set_builders_language() {

			$kata_options = get_option( 'kata_options' );

			if ( ! isset( $kata_options['multilanguage']['polylang'] ) && function_exists( 'pll_languages_list' ) && function_exists( 'pll_default_language' ) ) {

				$args = array(
					'numberposts' => -1,
					'post_type'   => 'kata_plus_builder',
				);

				$builders  = get_posts( $args );
				$languages = pll_languages_list();
				var_dump( $languages );

				foreach ( $languages as $language ) {

					if ( pll_default_language() != $language ) {

						foreach ( $builders as $builder ) {

							$new_builder = array(
								'post_title'    => $builder->post_title . ' ' . $language,
								'post_content'  => '',
								'post_status'   => 'publish',
								'post_date'     => date( 'Y-m-d H:i:s' ),
								'post_author'   => '',
								'post_type'     => 'kata_plus_builder',
								'post_category' => array( 0 ),
							);

							$translation = get_posts(
								array(
									'post_type'   => 'kata_plus_builder',
									'title'       => $new_builder['post_title'],
									'post_status' => 'all',
									'numberposts' => 1,
								)
							);

							if ( ! $translation ) {

								$translation_id = wp_insert_post( $new_builder );
								pll_set_post_language( $translation_id, $language );

								if ( $translation_id && ! is_wp_error( $translation_id ) ) {

									update_post_meta( $translation_id, '_elementor_edit_mode', 'builder' );
									update_post_meta( $translation_id, '_elementor_template_type', 'post' );
									update_post_meta( $translation_id, '_wp_page_template', 'default' );
									update_post_meta( $translation_id, '_edit_lock', time() . ':1' );
									update_post_meta( $translation_id, '_elementor_version', '0.4' );
									update_post_meta( $translation_id, '_elementor_data', get_post_meta( $builder->ID, '_elementor_data', true ) );
									update_post_meta( $translation_id, '_kata_builder_type', get_post_meta( $builder->ID, '_kata_builder_type', true ) );
									update_post_meta( $translation_id, '_' . get_post_meta( $builder->ID, '_kata_builder_type', true ) . '_primary', get_post_meta( $builder->ID, '_' . get_post_meta( $builder->ID, '_kata_builder_type', true ) . '_primary', true ) );
								}

								$builder_translations[ $language ]              = $translation_id;
								$builder_translations[ pll_default_language() ] = $builder->ID;
							}

							pll_save_post_translations( $builder_translations );
						}
					}
				}
			}

			$kata_options['multilanguage']['polylang'] = true;
			$kata_options['multilanguage']['wpml']     = false;

			update_option( 'kata_options', $kata_options );
		}

		/**
		 * Page Options.
		 *
		 * @since   1.0.0
		 */
		public function multi_language_url( $id ) {

			if ( function_exists( 'PLL' ) ) {

				$currnet_lang = pll_current_language() ? pll_current_language() : pll_default_language();
				$ids          = pll_get_post_translations( $id );
				$out          = '';

				foreach ( $ids as $key => $id ) {
					$out .= '<p class="kata-multi-lang-links">';
					$out .= '<a href="' . esc_url( admin_url( 'post.php?post=' . $id . '&action=elementor' ) ) . '" target="_blank">' . __( 'Edit', 'kata-plus' ) . ' ' . $key . ' ' . __( 'version', 'kata-plus' ) . '</a>';
					$out .= '</p>';
				}

				return $out;
			}
		}

		/**
		 * Page Options.
		 *
		 * @since   1.0.0
		 */
		public function multi_language( $page ) {
			$page->start_controls_section(
				'kata_multi_language',
				array(
					'label' => esc_html__( 'Multi-Language', 'kata-plus' ),
					'tab'   => Controls_Manager::TAB_SETTINGS,
				)
			);

			$page->add_control(
				'multi_lang_urls',
				array(
					'label'           => esc_html__( 'Important Note', 'plugin-name' ),
					'type'            => \Elementor\Controls_Manager::RAW_HTML,
					'raw'             => $this->multi_language_url( get_the_ID() ),
					'content_classes' => 'your-class',
				)
			);

			$page->end_controls_section();
		}

		/**
		 * Set default language for builders.
		 *
		 * @since   1.0.0
		 */
		public function set_default_language_for_builders() {

			if ( ! function_exists( 'pll_default_language' ) ) {
				return false;
			}

			$builders = get_posts(
				array(
					'post_type'   => 'kata_plus_builder',
					'numberposts' => -1,
				)
			);

			// The language code you want to set as the default language.
			$default_language = pll_default_language();

			foreach ( $builders as $builder ) {
				if ( pll_get_post_language( $builder->ID ) !== $default_language ) {
					pll_set_post_language( $builder->ID, $default_language );
				}
			}
		}
	}

	Kata_Plus_Pll_Compatibility::get_instance();
}
